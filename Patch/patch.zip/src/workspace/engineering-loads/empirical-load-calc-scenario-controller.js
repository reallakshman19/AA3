import { APPLICATION_EVENTS, EVENT_TOPICS } from '../event-topics.js';
import { SUPPORT_RESTRAINT_EVENTS } from '../support-restraint-events.js';
import { TOPOLOGY_EVENTS } from '../topology-events.js';
import { ENGINEERING_MODEL_EVENTS } from '../engineering-model-controller.js';
import {
  nonFeaMethodExecutionCoordinator,
} from '../non-fea-method-execution-coordinator.js';
import {
  assertEmpiricalCaseConfigurationsAuthorized,
  createNonFeaLoadCaseAuthority,
} from '../project-data/non-fea-load-case-authority.js';
import { projectDataStore } from '../project-data/project-data-store.js';
import {
  EMPIRICAL_LOAD_CALC_AUTHORIZATION_SCHEMA,
  EMPIRICAL_LOAD_CALC_SCENARIO_SNAPSHOT_SCHEMA,
  empiricalLoadCalcScenarioStore,
} from './empirical-load-calc-scenario-store.js';
import {
  createEmpiricalAnalysisScenario,
  createEmpiricalCoordinateFrame,
} from './contracts/empirical-sjson-contracts.js';
import {
  empiricalResultOverlayStore,
} from './empirical-result-overlay-store.js';
import { buildSjsonEmpiricalPipingRequest } from './adapters/sjson-to-empirical-piping-request.js';
import { createEmpiricalBeamContactRuntimeProfile } from './empirical-beam-contact-runtime-profile.js';

export const EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS = Object.freeze({
  CONFIGURE_REQUESTED: 'empirical-load-calc-scenario:configure-requested',
  AUTHORIZE_REQUESTED: 'empirical-load-calc-scenario:authorize-requested',
  CALCULATE_REQUESTED: 'empirical-load-calc-scenario:calculate-requested',
  CLONE_PROFILE_REQUESTED: 'empirical-load-calc-scenario:clone-profile-requested',
  SELECT_METHOD_REQUESTED: 'empirical-load-calc-scenario:select-method-requested',
  CHANGED: 'empirical-load-calc-scenario:changed',
  RESULT_OVERLAY_CHANGED: 'empirical-load-calc-scenario:result-overlay-changed',
  FAILED: 'empirical-load-calc-scenario:failed',
});

export class EmpiricalLoadCalcScenarioController {
  constructor(
    eventBus,
    authorityProvider = null,
    store = empiricalLoadCalcScenarioStore,
    executionCoordinator = nonFeaMethodExecutionCoordinator,
    loadCaseAuthorityProvider = () => createNonFeaLoadCaseAuthority(projectDataStore.getProfile()),
    resultOverlayStore = empiricalResultOverlayStore,
  ) {
    if (!eventBus || typeof eventBus.subscribe !== 'function'
      || typeof eventBus.publish !== 'function') {
      throw new TypeError('Empirical Load Calc scenario controller requires an event bus.');
    }
    if (!executionCoordinator
        || typeof executionCoordinator.prepareAuthorization !== 'function'
        || typeof executionCoordinator.recordAuthorization !== 'function'
        || typeof executionCoordinator.requireCurrentAuthorization !== 'function'
        || typeof executionCoordinator.recordExecution !== 'function') {
      throw new TypeError('Empirical Load Calc scenario controller requires the Non-FEA execution coordinator.');
    }
    if (typeof loadCaseAuthorityProvider !== 'function') {
      throw new TypeError('Empirical Load Calc scenario controller requires a Load Case authority provider.');
    }
    if (!resultOverlayStore
        || typeof resultOverlayStore.subscribe !== 'function'
        || typeof resultOverlayStore.sync !== 'function') {
      throw new TypeError('Empirical Load Calc scenario controller requires a governed result overlay store.');
    }
    this.eventBus = eventBus;
    this.authorityProvider = typeof authorityProvider === 'function'
      ? authorityProvider
      : () => null;
    this.store = store;
    this.executionCoordinator = executionCoordinator;
    this.loadCaseAuthorityProvider = loadCaseAuthorityProvider;
    this.resultOverlayStore = resultOverlayStore;
    this.unsubscribers = [];
  }

  init() {
    if (this.unsubscribers.length) return;
    this.unsubscribers = [
      this.eventBus.subscribe(
        EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.CONFIGURE_REQUESTED,
        (payload) => this.configure(payload),
      ),
      this.eventBus.subscribe(
        EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.AUTHORIZE_REQUESTED,
        (payload) => this.authorize(payload),
      ),
      this.eventBus.subscribe(
        EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.CALCULATE_REQUESTED,
        (payload) => this.calculate(payload),
      ),
      this.eventBus.subscribe(
        EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.CLONE_PROFILE_REQUESTED,
        (payload) => this.cloneProfile(payload),
      ),
      this.eventBus.subscribe(
        EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.SELECT_METHOD_REQUESTED,
        (payload) => this.selectMethod(payload?.methodId),
      ),
      this.eventBus.subscribe(
        EVENT_TOPICS.WORKSPACE_SNAPSHOT_CHANGED,
        () => this.refresh(),
      ),
      this.eventBus.subscribe(
        APPLICATION_EVENTS.CONTEXT_CHANGED,
        () => this.refresh(),
      ),
      this.eventBus.subscribe(
        SUPPORT_RESTRAINT_EVENTS.CHANGED,
        () => this.refresh(),
      ),
      this.eventBus.subscribe(
        TOPOLOGY_EVENTS.CHANGED,
        () => this.refresh(),
      ),
      this.eventBus.subscribe(
        ENGINEERING_MODEL_EVENTS.CHANGED,
        () => this.refresh(),
      ),
      projectDataStore.subscribe(() => this.refresh()),
      this.store.subscribe((snapshot) => this.#publishScenarioState(snapshot)),
      this.resultOverlayStore.subscribe(({ snapshot, projection, details }) => {
        this.eventBus.publish(
          EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.RESULT_OVERLAY_CHANGED,
          { snapshot, projection, details },
        );
      }),
    ];
    this.#publishScenarioState(this.store.getSnapshot());
  }

  configure(value) {
    return this.#run('configure', () => {
      this.#assertLoadCaseAuthority(value?.caseConfigurations);
      return this.store.configure(value);
    });
  }

  selectMethod(methodId) {
    return this.#run('select-method', () => {
      const provided = this.authorityProvider();
      if (!provided?.sharedModel || !provided?.topologyGraph) return this.store.getSnapshot();
      const proposal = createDefaultProposal(methodId, provided);
      if (proposal) {
        return this.configure(proposal);
      }
      return this.store.getSnapshot();
    });
  }

  authorize(value = {}) {
    this.refresh();
    return this.#run('authorize', () => {
      const proposal = requireProposal(this.store.getProposal());
      this.#assertLoadCaseAuthority(proposal.caseConfigurations);
      const authorizationId = value.authorizationId || generatedId('AUTH');
      const authorizedAt = value.authorizedAt || new Date().toISOString();
      const prepared = this.executionCoordinator.prepareAuthorization({
        authorizationId,
        authorizedAt,
        implementationId: proposal.method,
        scenarioId: proposal.scenarioId,
        methodRequestSemanticHash: proposal.semanticHash,
        analysisPlanSemanticHash: value.analysisPlanSemanticHash || null,
      });
      const snapshot = this.store.authorize({ authorizationId, authorizedAt });
      this.executionCoordinator.recordAuthorization(prepared.receipt);
      return snapshot;
    });
  }

  calculate(value = {}) {
    this.refresh();
    return this.#run('calculate', () => {
      const proposal = requireProposal(this.store.getProposal());
      this.#assertLoadCaseAuthority(proposal.caseConfigurations);
      const authorization = this.store.getAuthorization();
      if (!authorization) {
        throw codedError(
          'A common-input-bound empirical authorization is required.',
          'COMMON_INPUT_METHOD_AUTHORIZATION_REQUIRED',
        );
      }
      this.executionCoordinator.requireCurrentAuthorization({
        authorizationId: authorization.authorizationId,
        implementationId: proposal.method,
        analysisPlanSemanticHash: value.analysisPlanSemanticHash || null,
      });
      const executionId = value.executionId || generatedId('EXEC');
      const executedAt = value.executedAt || new Date().toISOString();
      const execution = this.store.execute({ executionId, executedAt });
      try {
        this.executionCoordinator.recordExecution({
          authorizationId: authorization.authorizationId,
          implementationId: proposal.method,
          analysisPlanSemanticHash: value.analysisPlanSemanticHash || null,
          executionId,
          executedAt,
          engineExecutionSemanticHash: execution.semanticHash,
          resultSemanticHash: execution.coreResult?.semanticHash || null,
          status: execution.coreResult?.status || 'UNKNOWN',
        });
      } catch (error) {
        this.#forceScenarioStale(proposal, 'missing:common-execution-receipt');
        throw error;
      }
      return execution;
    });
  }

  cloneProfile(value = {}) {
    return this.#run('clone-profile', () => {
      if (!this.store.getProposal()) {
        this.selectMethod(value.methodId || 'EMPIRICAL_BEAM_CONTACT_V1');
      }
      const profile = this.store.cloneProfile(value);
      this.eventBus.publish(
        EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.CHANGED,
        {
          snapshot: this.store.getSnapshot(),
          overlaySnapshot: this.resultOverlayStore.getSnapshot(),
          clonedProfile: profile,
        },
      );
      return profile;
    });
  }

  refresh() {
    let proposal = this.store.getProposal();
    if (!proposal) {
      const snapshot = this.store.getSnapshot();
      if (snapshot.state === 'NOT_CONFIGURED' && typeof this.authorityProvider === 'function') {
        try {
          const provided = this.authorityProvider();
          if (provided?.sharedModel && provided?.topologyGraph && provided?.supportAttachmentModel && provided?.restraintCapabilityModel) {
            const defaultProposal = createDefaultProposal('EMPIRICAL_BEAM_CONTACT_V1', provided);
            if (defaultProposal) {
              this.configure(defaultProposal);
              proposal = this.store.getProposal();
            }
          }
        } catch {
          // Allow normal failures on auto-configure to fail silently if dependencies aren't ready
        }
      }
      if (!proposal) return this.store.getSnapshot();
    }
    try {
      this.#assertLoadCaseAuthority(proposal.caseConfigurations);
      const provided = this.authorityProvider(proposal);
      if (provided) {
        this.store.refresh({
          datasetId: provided.datasetId,
          adaptedRequestSemanticHash: proposal.adaptedRequest.semanticHash,
          runtimeProfileSemanticHash: proposal.runtimeProfile.semanticHash,
          sharedModelSemanticHash: provided.sharedModel?.semanticHash || 'missing:shared-model',
          topologySemanticHash: provided.topologyGraph?.semanticHash || 'missing:topology',
          attachmentSemanticHash:
            provided.supportAttachmentModel?.semanticHash || 'missing:attachment',
          restraintSemanticHash:
            provided.restraintCapabilityModel?.semanticHash || 'missing:restraint',
          loadPrimitiveSetSemanticHash:
            provided.sourceLoadPrimitiveSet?.semanticHash || 'missing:load-primitives',
        });
      }
      this.#refreshCommonInputBinding(proposal);
      return this.store.getSnapshot();
    } catch (error) {
      if (this.store.getAuthorization()) {
        this.#forceScenarioStale(proposal, 'missing:current-project-data-load-case-authority');
      }
      this.#publishFailure('refresh', error);
      return this.store.getSnapshot();
    }
  }

  #assertLoadCaseAuthority(caseConfigurations) {
    const authority = this.loadCaseAuthorityProvider();
    return assertEmpiricalCaseConfigurationsAuthorized(authority, caseConfigurations || []);
  }

  #refreshCommonInputBinding(proposal) {
    const authorization = this.store.getAuthorization();
    if (!authorization) return;
    try {
      this.executionCoordinator.requireCurrentAuthorization({
        authorizationId: authorization.authorizationId,
        implementationId: proposal.method,
      });
    } catch {
      this.#forceScenarioStale(proposal, 'missing:current-common-input-or-implementation');
    }
  }

  #forceScenarioStale(proposal, marker) {
    this.store.refresh({
      ...proposal.bindings,
      adaptedRequestSemanticHash: marker,
    });
  }

  getSnapshot() { return this.store.getSnapshot(); }
  getProposal() { return this.store.getProposal(); }
  getAuthorization() { return this.store.getAuthorization(); }
  getExecution() { return this.store.getExecution(); }
  getResultOverlaySnapshot() { return this.resultOverlayStore.getSnapshot(); }
  getResultOverlayProjection() { return this.resultOverlayStore.getProjection(); }

  destroy() {
    this.unsubscribers.forEach((unsubscribe) => unsubscribe());
    this.unsubscribers = [];
    this.resultOverlayStore.clear('EMPIRICAL_SCENARIO_CONTROLLER_DESTROYED');
    this.store.clear('EMPIRICAL_SCENARIO_CONTROLLER_DESTROYED');
  }

  #publishScenarioState(snapshot) {
    const overlaySnapshot = this.resultOverlayStore.sync({
      snapshot,
      proposal: this.store.getProposal(),
      execution: this.store.getExecution(),
    });
    this.eventBus.publish(
      EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.CHANGED,
      { snapshot, overlaySnapshot },
    );
  }

  #run(operation, callback) {
    try {
      return callback();
    } catch (error) {
      this.#publishFailure(operation, error);
      return null;
    }
  }

  #publishFailure(operation, error) {
    this.eventBus.publish(EMPIRICAL_LOAD_CALC_SCENARIO_EVENTS.FAILED, {
      operation,
      code: error?.code || 'EMPIRICAL_SCENARIO_OPERATION_FAILED',
      message: error instanceof Error ? error.message : String(error),
      details: error?.details || null,
    });
  }
}

function requireProposal(value) {
  if (!value) throw codedError('An empirical scenario proposal is required.', 'EMPIRICAL_SCENARIO_REQUIRED');
  return value;
}
function generatedId(prefix) {
  const random = globalThis.crypto?.randomUUID?.()
    || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  return `${prefix}:${random}`;
}
function codedError(message, code) {
  const error = new Error(message);
  error.code = code;
  return error;
}

export function createDefaultProposal(methodId = 'EMPIRICAL_BEAM_CONTACT_V1', provided) {
  if (!provided?.sharedModel || !provided?.topologyGraph || !provided?.supportAttachmentModel || !provided?.restraintCapabilityModel) {
    return null;
  }
  const datasetId = provided.sharedModel.project?.datasetId || provided.datasetId || 'DEFAULT';
  const validMethod = [
    'EMPIRICAL_BEAM_CONTACT_V1',
    'EMPIRICAL_RESTRAINT_NETWORK_V1',
    'EMPIRICAL_RESTRAINT_NETWORK_V2',
  ].includes(methodId) ? methodId : 'EMPIRICAL_BEAM_CONTACT_V1';

  const lineProperties = {};
  const lineIds = new Set((provided.sharedModel.components || []).map((c) => c.identity?.lineId || 'L1'));
  if (lineIds.size === 0) lineIds.add('L1');

  for (const lineId of lineIds) {
    lineProperties[lineId] = {
      outsideDiameterM: 0.16828,
      nominalWallM: 0.00711,
      stiffnessWallM: 0.00711,
      weightWallM: 0.00711,
      corrosionAllowanceM: 0,
      elasticModulusPa: 200e9,
      thermalExpansionPerK: 12e-6,
      authority: {
        section: 'DEFAULT_POLICY',
        elasticModulus: 'DEFAULT_POLICY',
        thermalExpansion: 'DEFAULT_POLICY',
      },
    };
  }

  const runtimeProfile = createEmpiricalBeamContactRuntimeProfile({
    profileId: `${validMethod}-DEFAULT`,
    profileVersion: 1,
    qualification: 'QUALIFIED',
    locked: true,
    lineProperties,
    elbow: { segmentCount: 8, flexibilityFactor: 1 },
    tolerances: {
      planarityM: 1e-9,
      pointProjectionM: 1e-8,
      contactGapM: 1e-9,
      absoluteReactionN: 1e-6,
      relativeReaction: 1e-10,
      equilibriumForceN: 1e-4,
      equilibriumMomentNm: 1e-4,
    },
    numericalOptions: {
      pivotMultiplier: 100,
      minimumReciprocalCondition: 1e-12,
    },
  });

  const coordinateFrame = createEmpiricalCoordinateFrame({
    sourceBasis: 'SJSON_SOURCE',
    sourceLengthUnit: 'mm',
    verticalUnitVector: [0, 0, 1],
    analysisPlaneBasis: {
      u: [1, 0, 0],
      v: [0, 0, 1],
      normal: [0, -1, 0],
    },
    forceOutputConvention: 'RESTRAINT_ON_PIPE',
    momentOutputConvention: 'RESTRAINT_ON_PIPE',
  });

  const scenario = createEmpiricalAnalysisScenario({
    scenarioId: `SCENARIO-${validMethod}`,
    name: `Default Empirical Scenario (${validMethod})`,
    method: validMethod,
    state: 'DRAFT',
    coordinateFrame,
    loadCases: [{
      loadCaseId: 'W-COLD',
      label: 'Cold weight',
      resultClass: 'VERTICAL_SCREENING_RESULT',
      effects: {
        weight: true,
        thermalStrain: false,
        pressureCompatibility: false,
        pressureStress: false,
      },
    }],
    restraintOverrides: [],
    profileRef: {
      profileId: runtimeProfile.profileId,
      profileVersion: runtimeProfile.profileVersion,
      qualification: runtimeProfile.qualification,
      locked: runtimeProfile.locked,
      semanticHash: runtimeProfile.semanticHash,
    },
    sourceBindings: {
      datasetHash: provided.sharedModel.sourceSnapshotRef?.sourceByteHash || 'sha256:default',
      sharedModelHash: provided.sharedModel.semanticHash,
      topologyHash: provided.topologyGraph.semanticHash,
      attachmentHash: provided.supportAttachmentModel.semanticHash,
      restraintHash: provided.restraintCapabilityModel.semanticHash,
      profileHash: runtimeProfile.semanticHash,
    },
    combinationPolicy: 'SEPARATE_UNTIL_QUALIFIED',
  });

  const adaptedRequest = buildSjsonEmpiricalPipingRequest({
    dataset: { datasetId, sourceSha256: 'sha256:default' },
    sharedModel: provided.sharedModel,
    topologyGraph: provided.topologyGraph,
    supportAttachmentModel: provided.supportAttachmentModel,
    restraintCapabilityModel: provided.restraintCapabilityModel,
    scenario,
  });

  return {
    adaptedRequest,
    runtimeProfile,
    sharedModel: provided.sharedModel,
    topologyGraph: provided.topologyGraph,
    supportAttachmentModel: provided.supportAttachmentModel,
    restraintCapabilityModel: provided.restraintCapabilityModel,
    sourceLoadPrimitiveSet: provided.sourceLoadPrimitiveSet || { loadPrimitives: [] },
    caseConfigurations: [{
      loadCaseId: 'W-COLD',
      weightPrimitiveCaseId: 'EMPTY',
      referenceTemperatureC: null,
      analysisTemperatureC: null,
    }],
  };
}

